export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: 'AIzaSyAHOoqSL9uIOBIVsv6EguLFR9dmDH11K-8',
    authDomain: 'split-digit.firebaseapp.com',
    projectId: 'split-digit',
    storageBucket: 'split-digit.firebasestorage.app',
    messagingSenderId: '511904808676',
    appId: '1:511904808676:web:2359a5907c6f37bc4476f1',
    measurementId: 'G-707LL94CP2',
  },
};
