import { Component } from '@angular/core';
import { UserRepository } from '../model/user.repository';
import { User } from '../model/user.model';
import { Router } from '@angular/router';

@Component({
  selector: 'addUsers',
  templateUrl: 'addUser.component.html',
  styleUrl: 'addUser.component.css',
})
export class AddUserComponent {
  searchEmail: string = '';
  members: User[] = [];
  filteredMembers: User[] = [];
  selectedMembers: User[] = [];

  constructor(private userRepo: UserRepository, private router: Router) {
    // Load all users from the repository
    this.members = this.userRepo.getUsers();
    this.filteredMembers = [...this.members]; // Initially show all users
  }

  // Filter members based on search input
  filterMembers(): void {
    const term = this.searchEmail.toLowerCase();
    this.filteredMembers = this.members.filter((member) =>
      member.email?.toLowerCase().includes(term)
    );
  }

  // Add member to selected list if not already added
  addToSelected(member: User): void {
    const alreadySelected = this.selectedMembers.some(
      (m) => m.email === member.email
    );
    if (!alreadySelected) {
      this.selectedMembers.push(member);
    }
  }

  // Confirm selection and navigate to group details
  confirmSelection(): void {
    this.router.navigate(['/group-details', '102']); // Replace '102' with dynamic group ID if needed
  }
}